import pygame
import pytmx
from pytmx.util_pygame import load_pygame
from sauvegarde import SaveData


import pygame
import pytmx
from pytmx.util_pygame import load_pygame
from sauvegarde import SaveData


class Carte:
    def __init__(self):
        self.tmxdata = load_pygame('map.tmx')
        self.tilewidth = self.tmxdata.tilewidth
        self.tileheight = self.tmxdata.tileheight
        self.layer1 = self.tmxdata.get_layer_by_name('Calque de Tuiles 1')

        self.obj_layer = self.tmxdata.get_layer_by_name('objets')
        self.collision_layer = self.tmxdata.get_layer_by_name('Calque de Tuiles 1')
        self.collision_tiles = []

        for x, y, tile in self.collision_layer.tiles():
            if tile:
                self.collision_tiles.append(pygame.Rect(x * self.tilewidth, y * self.tileheight, self.tilewidth, self.tileheight))

        # Charger les données sauvegardées pour les objets supprimés
        self.save_data = SaveData('save.json')
        self.removed_objects = self.save_data.load_removed_objects()

        # Si le fichier de sauvegarde est vide ou n'existe pas, réinitialiser la liste des objets supprimés
        if self.removed_objects is None:
            self.removed_objects = []

        # Ajouter tous les objets supprimés à la couche d'objets
        if self.removed_objects:
            for obj in self.obj_layer:
                if obj.name in self.removed_objects:
                    self.obj_layer.remove(obj)
                else:
                    obj.add_to_layer()

        # Ajouter les objets supprimés à la liste des objets supprimés dans les données sauvegardées
        for obj in self.obj_layer:
            if obj.name not in self.removed_objects:
                self.removed_objects.append(obj.name)
                self.save_data.save_removed_objects(self.removed_objects)


    def remove_object(self, obj_name):
        # Supprimer l'objet de la couche d'objets
        for obj in self.obj_layer:
            if obj.name == obj_name:
                self.obj_layer.remove(obj)
                break
                
        # Ajouter l'objet à la liste des objets supprimés dans les données sauvegardées
        if obj_name not in self.removed_objects:
            self.removed_objects.append(obj_name)
            self.save_data.save_removed_objects(self.removed_objects)
            
    def draw(self, screen, camera_x, camera_y):
        screen.fill((0, 0, 0))

        for x, y, image in self.layer1.tiles():
            screen.blit(image, (x * self.tilewidth - camera_x, y * self.tileheight - camera_y))
        
        # Dessiner uniquement les objets qui ne sont pas supprimés
        for obj in self.obj_layer:
            if obj.name not in self.removed_objects:
                screen.blit(obj.image, (obj.x - camera_x, obj.y - camera_y))

    
    def get_pickup_distance(self, tmx_data):
        # Extraire la position de l'objet à collecter
        obj_pos = []
        for obj in tmx_data.objects:
            obj_pos.append((obj.name, (obj.x, obj.y)))
        # Définir la distance à laquelle le joueur peut ramasser l'objet
        pickup_distance = 50

        return obj_pos, pickup_distance


    def get_collision_tiles(self):
        return self.collision_tiles

    def get_width(self):
        return self.tmxdata.width * self.tilewidth

    def get_height(self):
        return self.tmxdata.height * self.tileheight
    
class MapObject:
    def __init__(self, name, x, y, width, height, properties):
        self.name = name
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.properties = properties
        self.picked_up = False # nouvel attribut pour indiquer si l'objet a été ramassé
    
