import pygame
import sys

class ResetMenu:
    def __init__(self, screen_width, screen_height):
        self.screen_width = screen_width
        self.screen_height = screen_height

        # Initialise Pygame
        pygame.init()

        # Crée la fenêtre de menu
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height), pygame.SRCALPHA)

        # Charge les images pour les boutons du menu
        self.reset_button_image = pygame.image.load("reset.png")
        self.cancel_button_image = pygame.image.load("cancel.png")

        # Redimensionne les images des boutons à 75% de leur taille d'origine
        button_size = (int(self.reset_button_image.get_width() * 0.75), int(self.reset_button_image.get_height() * 0.75))
        self.reset_button_image = pygame.transform.scale(self.reset_button_image, button_size)
        self.cancel_button_image = pygame.transform.scale(self.cancel_button_image, button_size)

        # Positionne les boutons sur la fenêtre de menu
        button_spacing = 50
        self.cancel_button_rect = self.cancel_button_image.get_rect()
        self.cancel_button_rect.centerx = self.screen_width // 3
        self.cancel_button_rect.centery = self.screen_height // 3

        self.reset_button_rect = self.reset_button_image.get_rect()
        self.reset_button_rect.centerx = self.screen_width // 2
        self.reset_button_rect.centery = self.screen_height // 3

    def run(self):
        while True:
            # gestion des événements Pygame
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = pygame.mouse.get_pos()
                    if self.reset_button_rect.collidepoint(mouse_pos):
                        return True
                    elif self.cancel_button_rect.collidepoint(mouse_pos):
                        return False

            # effacer l'écran
            self.screen.fill((255, 255, 255, 0), special_flags=pygame.BLEND_RGBA_MULT)

            # afficher les boutons
            self.screen.blit(self.reset_button_image, self.reset_button_rect)
            self.screen.blit(self.cancel_button_image, self.cancel_button_rect)

            # rafraîchir l'affichage de la fenêtre
            pygame.display.flip()
