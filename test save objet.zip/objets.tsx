<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="objets" tilewidth="16" tileheight="16" tilecount="660" columns="33">
 <image source="../gfx/objects.png" width="528" height="320"/>
</tileset>
