<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Projet trans" tilewidth="16" tileheight="16" tilecount="1440" columns="40">
 <image source="../gfx/Overworld.png" width="640" height="576"/>
 <wangsets>
  <wangset name="map test" type="corner" tile="-1">
   <wangcolor name="falaise" color="#ff0000" tile="-1" probability="1"/>
   <wangtile tileid="484" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="485" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="486" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="524" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="525" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="526" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="564" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="565" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="566" wangid="0,1,0,1,0,1,0,1"/>
  </wangset>
 </wangsets>
</tileset>
