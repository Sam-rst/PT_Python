import pygame
import sys
from pytmx.util_pygame import load_pygame

class Player:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.animation_droite = [pygame.image.load("droite.png"), pygame.image.load("droite2.png"), pygame.image.load("droite3.png"), pygame.image.load("droite4.png")]
        self.animation_gauche = [pygame.image.load("gauche.png"), pygame.image.load("gauche2.png"), pygame.image.load("gauche3.png"), pygame.image.load("gauche4.png")]
        self.animation_haut = [pygame.image.load("haut.png"), pygame.image.load("haut2.png"), pygame.image.load("haut3.png"), pygame.image.load("haut4.png")]
        self.animation_bas = [pygame.image.load("bas.png"), pygame.image.load("bas2.png"), pygame.image.load("bas3.png"), pygame.image.load("bas4.png")]
        self.direction = 'droite'
        self.compteur_animation = 0
        self.temps_animation = 1 / 5
        self.is_moving = False
        self.player_speed = 50
        self.player_rect = pygame.Rect(self.x, self.y, 10, 10)
        self.image = pygame.image.load('bas.png')
        self.rect = self.image.get_rect()
        self.current_animation = self.animation_bas

    def move(self, dt, keys):
        if keys[pygame.K_z]:
            self.y -= self.player_speed * dt
            self.direction = 'haut'
            self.is_moving = True
        elif keys[pygame.K_s]:
            self.y += self.player_speed * dt
            self.direction = 'bas'
            self.is_moving = True
        if keys[pygame.K_q]:
            self.x -= self.player_speed * dt
            self.direction = 'gauche'
            self.is_moving = True
        elif keys[pygame.K_d]:
            self.x += self.player_speed * dt
            self.direction = 'droite'
            self.is_moving = True
        else:
            self.is_moving = False
    

    def update_animation(self, dt):
        # Déterminez quelle animation du personnage doit être affichée en fonction de la direction de déplacement
        if self.direction == "droite":
            self.current_animation = self.animation_droite
        elif self.direction == "gauche":
            self.current_animation = self.animation_gauche
        elif self.direction == "haut":
            self.current_animation = self.animation_haut
        elif self.direction == "bas":
            self.current_animation = self.animation_bas

        # Incrémentez le compteur d'animation pour passer à l'image suivante
        self.compteur_animation += dt / self.temps_animation

        if self.compteur_animation >= len(self.current_animation):
            self.compteur_animation = 0

    def update_rect(self):
        self.player_rect = pygame.Rect(self.x, self.y, 10, 10)

    def get_image(self):
        return self.current_animation[int(self.compteur_animation)]
    def get_position(self):
        return self.x, self.y
    
   


