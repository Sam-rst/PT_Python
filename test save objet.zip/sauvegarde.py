import os
import json

class SaveData:
    def __init__(self, filename):
        self.filename = filename

    def save_player_position(self, player_position):
        try:
            with open(self.filename, "r") as file:
                data = json.load(file)
        except FileNotFoundError:
            data = {}

        data["player_position"] = player_position

        try:
            with open(self.filename, "w") as file:
                json.dump(data, file)
        except IOError:
            print("Erreur lors de l'écriture du fichier de sauvegarde.")

    def load_player_data(self):
        try:
            with open(self.filename, "r") as file:
                data = json.load(file)
                return data
        except FileNotFoundError:
            return None

    def save_removed_objects(self, removed_objects):
        try:
            with open(self.filename, "r") as file:
                data = json.load(file)
        except FileNotFoundError:
            data = {}

        # Si des données existent déjà dans le fichier, on ajoute les objets supprimés à ces données
        if "removed_objects" in data:
            data["removed_objects"].extend(removed_objects)
        else:
            data["removed_objects"] = removed_objects

        try:
            with open(self.filename, "w") as file:
                json.dump(data, file)
        except IOError:
            print("Erreur lors de l'écriture du fichier de sauvegarde.")

    def load_removed_objects(self):
        try:
            with open(self.filename, "r") as file:
                data = json.load(file)
                if "removed_objects" in data:
                    return data["removed_objects"]
                else:
                    return []
        except FileNotFoundError:
            return []

    def reset(self):
        try:
            os.remove(self.filename)
        except FileNotFoundError:
            pass
