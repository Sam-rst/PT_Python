import pygame, os, math
from carte import *
from player import *
from sauvegarde import SaveData
from pytmx.util_pygame import load_pygame
from menu import ResetMenu

class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
        self.clock = pygame.time.Clock()
        pygame.key.set_repeat(1, 1)

        self.map = Carte()
        self.player = Player(400, 300)
        self.save_data = SaveData("save.json")
        self.frame_counter = 0
        self.last_save_time = pygame.time.get_ticks()
        # Charger les données sauvegardées pour initialiser la position du joueur
        player_data = self.save_data.load_player_data()
        if player_data is not None:
            position_data = player_data.get("player_position") # accéder au dictionnaire de position du joueur
            if position_data is not None:
                self.player = Player(position_data["x"], position_data["y"]) # récupérer les coordonnées x et y du joueur
        else:
            self.player = Player(400, 300)

        self.reset_menu = ResetMenu(self.screen.get_width(), self.screen.get_height())

    def run(self):
        running = True
        while running:
            dt = self.clock.tick(60) / 1000

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_e:
                        obj_pos, pickup_distance = self.map.get_pickup_distance(self.map.tmxdata)
                        player_x, player_y = self.player.get_position()
                        removed_objects = []
                        for obj in obj_pos:
                            obj_name = obj[0]
                            obj_pos = obj[1]
                            distance = math.sqrt((player_x - obj_pos[0])**2 + (player_y - obj_pos[1])**2)
                            if distance < pickup_distance:
                                self.map.remove_object(obj_name)
                                removed_objects.append(obj_name)
                        if removed_objects:
                            self.save_data.save_removed_objects(removed_objects)
                        elif event.key == pygame.K_ESCAPE:
                            menu_choice = self.reset_menu.run()
                        if menu_choice == "reset":
                                    # Reset the game
                                pass # TODO: Implement game reset logic
                        elif menu_choice == "cancel":
                                    # Continue the game
                            pass # TODO: Implement game continue logic

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = pygame.mouse.get_pos()
                    if self.reset_menu.reset_button_rect.collidepoint(mouse_pos):
                        return "reset"
                    elif self.reset_menu.cancel_button_rect.collidepoint(mouse_pos):
                        return "cancel"

            # Dessine les éléments du menu sur la fenêtre
            self.screen.fill((255, 255, 255))
            self.screen.blit(self.player.get_image(), (400, 300))


            keys = pygame.key.get_pressed()
            self.player.move(dt, keys)
            self.player.update_animation(dt)

            if not self.player.is_moving:
                self.player.compteur_animation = 0

            collision_tiles = self.map.get_collision_tiles()
            player_rect = pygame.Rect(self.player.x, self.player.y, 32, 32)
            for tile_rect in collision_tiles:
                if player_rect.colliderect(tile_rect):
                    if self.player.direction == "droite":
                        self.player.x = tile_rect.left - 32
                    elif self.player.direction == "gauche":
                        self.player.x = tile_rect.right
                    elif self.player.direction == "bas":
                        self.player.y = tile_rect.top - 32
                    elif self.player.direction == "haut":
                        self.player.y = tile_rect.bottom

            camera_x = self.player.x - 400
            camera_y = self.player.y - 300
            self.map.draw(self.screen, camera_x, camera_y)
            self.screen.blit(self.player.get_image(), (400, 300))

            

            # Sauvegarde la position du joueur toutes les 5 secondes
            current_time = pygame.time.get_ticks()
            if current_time - self.last_save_time > 5000:
                player_position = {"x": self.player.x, "y": self.player.y}
                self.save_data.save_player_position(player_position)
                self.last_save_time = current_time

            pygame.display.flip()

        pygame.quit()


